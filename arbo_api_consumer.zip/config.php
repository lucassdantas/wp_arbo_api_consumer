<?php
// Define a chave da API como uma constante
define('ARBO_API_KEY', 'chave-da-api-aqui');
