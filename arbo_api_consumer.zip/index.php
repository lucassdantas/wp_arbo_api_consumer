<?php 
//AMGD